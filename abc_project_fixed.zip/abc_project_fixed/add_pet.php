<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name         = trim($_POST['name'] ?? '');
    $species      = trim($_POST['species'] ?? '');
    $breed        = trim($_POST['breed'] ?? '');
    $age          = trim($_POST['age'] ?? '');
    $gender       = trim($_POST['gender'] ?? '');
    $weight       = $_POST['weight'] !== '' ? floatval($_POST['weight']) : null;
    $adoption_fee = $_POST['adoption_fee'] !== '' ? floatval($_POST['adoption_fee']) : null;
    $behaviour    = trim($_POST['behaviour'] ?? '');
    $status       = 'available';

    // Image upload handling
    $image_path = null;
    if (!empty($_FILES['image']['name'])) {
        $upload_dir = "uploads/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $image_name = time() . "_" . basename($_FILES['image']['name']);
        $target_path = $upload_dir . $image_name;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            $image_path = $target_path;
        }
    }

    if (!$name || !$species || !$gender) {
        die("Missing required fields (Name, Species, Gender).");
    }

    $stmt = $conn->prepare("INSERT INTO pets 
        (name, species, breed, age, gender, weight, adoption_fee, behaviour, image, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) die("Prepare failed: " . $conn->error);

    $stmt->bind_param(
        'sssssdssss',
        $name,
        $species,
        $breed,
        $age,
        $gender,
        $weight,
        $adoption_fee,
        $behaviour,
        $image_path,
        $status
    );

    if ($stmt->execute()) {
        echo "<p style='padding:16px;background:#e9ffe9;border:1px solid #c7f0c7;'>Pet added successfully!</p>";
        echo "<p><a href='admin.php' class='button'>Back to Admin</a></p>";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!-- Add Pet Form -->
<form action="" method="post" enctype="multipart/form-data">
    <label>Name:</label>
    <input type="text" name="name" required>

    <label>Species:</label>
    <input type="text" name="species" required>

    <label>Breed:</label>
    <input type="text" name="breed">

    <label>Age:</label>
    <input type="text" name="age">

    <label>Gender:</label>
    <select name="gender" required>
        <option value="">--Select--</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
    </select>

    <label>Weight (kg):</label>
    <input type="number" step="0.01" name="weight">

    <label>Adoption Fee:</label>
    <input type="number" step="0.01" name="adoption_fee">

    <label>Behaviour:</label>
    <textarea name="behaviour"></textarea>

    <label>Image:</label>
    <input type="file" name="image">

    <button type="submit" name="submit">Add Pet</button>
</form>
