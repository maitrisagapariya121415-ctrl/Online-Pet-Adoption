<?php include 'db.php'; ?>

<html>
<head>
  <meta charset="utf-8">
  <title>Online Pet Adoption</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <div class="header">
    <h1>Online Pet Adoption</h1>
    <div>
      <?php if (!empty($_SESSION['user_id'])): ?>
        <a class="button" href="user_dashboard.php">Dashboard (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
        <a class="button red" href="logout.php">Logout</a>
      <?php else: ?>
        <a class="button" href="login.php">Login</a>
        <a class="button" href="register.php">Register</a>
      <?php endif; ?>
      <a class="button" href="admin.php">Admin</a>
    </div>
  </div>

  <div class="pet-list">
    <?php
    // Fetch all fields from DB
    $stmt = $conn->prepare("
        SELECT id, name, species, breed, age, gender, weight, adoption_fee, behaviour, image, status 
        FROM pets 
        ORDER BY created_at DESC
    ");
    $stmt->execute();
    $res = $stmt->get_result();

    while ($row = $res->fetch_assoc()) {
        $filePath = __DIR__ . "/uploads/" . ($row['image'] ?? '');
        $img = $row['image'];
        
        echo '<div class="card">';
        echo "<img src=\"{$img}\" alt=\"".htmlspecialchars($row['name'])."\">";
        echo "<h3>".htmlspecialchars($row['name'])."</h3>";
        
        echo "<p><strong>Species:</strong> ".htmlspecialchars($row['species'])."</p>";
        if (!empty($row['breed'])) {
            echo "<p><strong>Breed:</strong> ".htmlspecialchars($row['breed'])."</p>";
        }
        if (!empty($row['age'])) {
            echo "<p><strong>Age:</strong> ".htmlspecialchars($row['age'])."</p>";
        }

        echo "<p><strong>Gender:</strong> ".ucfirst(htmlspecialchars($row['gender']))."</p>";
        
        if (!empty($row['weight'])) {
            echo "<p><strong>Weight:</strong> ".number_format($row['weight'], 2)." kg</p>";
        }

        if ($row['adoption_fee'] !== null) {
            echo "<p><strong>Adoption Fee:</strong> ₹".number_format($row['adoption_fee'], 2)."</p>";
        } else {
            echo "<p><strong>Adoption Fee:</strong> Not specified</p>";
        }

        if (!empty($row['behaviour'])) {
            echo "<p><strong>Behaviour:</strong> ".nl2br(htmlspecialchars(substr($row['behaviour'],0,120)))."...</p>";
        }

        if ($row['status'] === 'available') {
            echo "<a class='button' href='pet.php?id={$row['id']}'>View & Adopt</a>";
        } else {
            echo "<span class='button red'>Adopted</span>";
        }
        echo '</div>';
    }
    $stmt->close();
    ?>
  </div>
</div>

<script src="app.js"></script>
</body>
</html>
