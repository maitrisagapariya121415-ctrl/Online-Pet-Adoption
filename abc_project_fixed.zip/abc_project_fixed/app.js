document.addEventListener('DOMContentLoaded', function(){
  var c = document.querySelector('.container');
  if (c) { c.style.opacity = 0; setTimeout(()=>{ c.style.transition='opacity 0.4s'; c.style.opacity = 1; }, 50); }
});
