<?php
include 'db.php';
$id = intval($_POST['id'] ?? 0);
if (!$id) die("Invalid ID");

// delete image file if exists
$r = $conn->prepare("SELECT image FROM pets WHERE id=?");
$r->bind_param('i',$id);
$r->execute();
$res = $r->get_result();
$row = $res->fetch_assoc();
if ($row && $row['image']) {
    @unlink(__DIR__ . '/uploads/' . $row['image']);
}

$del = $conn->prepare("DELETE FROM pets WHERE id=?");
$del->bind_param('i',$id);
$del->execute();
header("Location: admin.php");
exit;
?>
