<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if (!$name || !$email || !$password) {
        $err = "All fields are required.";
    } elseif ($password !== $password2) {
        $err = "Passwords do not match.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
        if (!$stmt) die("Prepare failed: " . $conn->error);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $err = "Email already registered.";
        } else {
            $stmt->close();
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            if (!$stmt) die("Prepare failed: " . $conn->error);
            $stmt->bind_param('sss', $name, $email, $hashed_password);
            if ($stmt->execute()) {
                header("Location: login.php?success=1");
                exit;
            } else {
                $err = "Registration failed: " . $stmt->error;
            }
        }
        $stmt->close();
    }
}
?>
<html>
    <head>
        <meta charset="utf-8"><title>Register</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
<div class="container">
  <h2>Register</h2>
  <?php if (!empty($err)) echo '<p style="color:red;">'.htmlspecialchars($err).'</p>'; ?>
  <form method="post" class="form">
    <input name="name" placeholder="Name" required>
    <input name="email" type="email" placeholder="Email" required>
    <input name="password" type="password" placeholder="Password" required>
    <input name="password2" type="password" placeholder="Repeat Password" required>
    <button class="button" type="submit">Register</button>
  </form>
  <p>Already have an account? <a href="login.php">Login</a></p>
</div>
<script src="app.js"></script>
</body>
</html>
