<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $err = "Email and password required.";
    } else {
        $stmt = $conn->prepare('SELECT id, name, password FROM users WHERE email=? LIMIT 1');
        if (!$stmt) die("Prepare failed: " . $conn->error);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $res = $stmt->get_result();
        $user = $res->fetch_assoc();
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['name'];
            header('Location: index.php');
            exit;
        } else {
            $err = "Invalid credentials.";
        }
    }
}
?>
<html>
    <head>
        <meta charset="utf-8"><title>Login</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
<div class="container">
  <h2>Login</h2>
  <?php if (!empty($_GET['success'])) echo "<p style='color:green;'>Registration complete. Please login.</p>"; ?>
  <?php if (!empty($err)) echo '<p style="color:red;">'.htmlspecialchars($err).'</p>'; ?>
  <form method="post" class="form">
    <input name="email" type="email" placeholder="Email" required>
    <input name="password" type="password" placeholder="Password" required>
    <button class="button" type="submit">Login</button>
  </form>
  <p>No account? <a href="register.php">Register</a></p>
</div>
<script src="app.js"></script>
</body></html>
