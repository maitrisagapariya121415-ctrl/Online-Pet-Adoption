<?php
include 'db.php';
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$username = htmlspecialchars($_SESSION['username']);
$email = '';
$stmt = $conn->prepare('SELECT email FROM users WHERE id=?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$res = $stmt->get_result();
if ($row = $res->fetch_assoc()) $email = $row['email'];
?>
<html>
  <head>
    <meta charset="utf-8"><title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
<div class="container">
  <h2>Welcome, <?php echo $username; ?></h2>
  <p>Your email: <?php echo htmlspecialchars($email); ?></p>
  <h3>Your Applications</h3>
  <table style="width:100%; background:white; padding:8px;">
    <tr><th>Pet</th><th></th><th>Applied At</th></tr>
    <?php
    $q = $conn->prepare('SELECT a.message, a.applied_at, p.name FROM applications a LEFT JOIN pets p ON a.pet_id = p.id WHERE a.adopter_email = ? ORDER BY a.applied_at DESC');
    $q->bind_param('s', $email);
    $q->execute();
    $r = $q->get_result();
    while ($row = $r->fetch_assoc()) {
        echo '<tr><td>'.htmlspecialchars($row['name']).'</td><td>'.htmlspecialchars($row['message']).'</td><td>'.htmlspecialchars($row['applied_at']).'</td></tr>';
    }
    ?>
  </table>
  <p><a class="button" href="index.php">Back to Home</a> <a class="button red" href="logout.php">Logout</a></p>
</div>
<script src="app.js"></script>
</body>
</html>
