<?php 
include 'db.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $conn->prepare("SELECT * FROM pets WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$pet = $res->fetch_assoc();
$stmt->close();

if (!$pet) {
    die("Pet not found.");
}

// prefill email if logged in
$user_email = '';
if (!empty($_SESSION['user_id'])) {
    $st = $conn->prepare("SELECT email FROM users WHERE id = ?");
    $st->bind_param('i', $_SESSION['user_id']);
    $st->execute();
    $r = $st->get_result();
    if ($ro = $r->fetch_assoc()) {
        $user_email = $ro['email'];
    }
    $st->close();
}

// Image handling
$filePath = __DIR__ . "/uploads/" . ($pet['image'] ?? '');
$img = (!empty($pet['image']) && file_exists($filePath)) 
    ? 'uploads/' . $pet['image'] 
    : 'https://via.placeholder.com/600x400?text=No+Image';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars($pet['name']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <a href="index.php" class="button">Back to list</a>
  
  <div class="card" style="margin-top:12px;">
    <img src="<?php echo $img; ?>" alt="">
    <h2><?php echo htmlspecialchars($pet['name']); ?></h2>
    <p><strong>Species:</strong> <?php echo htmlspecialchars($pet['species']); ?></p>
    <?php if (!empty($pet['breed'])): ?>
      <p><strong>Breed:</strong> <?php echo htmlspecialchars($pet['breed']); ?></p>
    <?php endif; ?>
    <?php if (!empty($pet['age'])): ?>
      <p><strong>Age:</strong> <?php echo htmlspecialchars($pet['age']); ?></p>
    <?php endif; ?>
    <p><strong>Gender:</strong> <?php echo ucfirst(htmlspecialchars($pet['gender'])); ?></p>
    <?php if (!empty($pet['weight'])): ?>
      <p><strong>Weight:</strong> <?php echo number_format($pet['weight'], 2); ?> kg</p>
    <?php endif; ?>
    <?php if ($pet['adoption_fee'] !== null): ?>
      <p><strong>Adoption Fee:</strong> ₹<?php echo number_format($pet['adoption_fee'], 2); ?></p>
    <?php else: ?>
      <p><strong>Adoption Fee:</strong> Not specified</p>
    <?php endif; ?>
    <?php if (!empty($pet['behaviour'])): ?>
      <p><strong>Behaviour:</strong><br><?php echo nl2br(htmlspecialchars($pet['behaviour'])); ?></p>
    <?php endif; ?>
    <?php if (!empty($pet['description'])): ?>
      <p><strong>Description:</strong><br><?php echo nl2br(htmlspecialchars($pet['description'])); ?></p>
    <?php endif; ?>
    <p><strong>Status:</strong> <?php echo htmlspecialchars($pet['status']); ?></p>
  </div>

  <?php if ($pet['status'] === 'available'): ?>
      <div class="form">
        <h3>Apply to Adopt</h3>
        <form action="adopt.php" method="post">
          <input type="hidden" name="pet_id" value="<?php echo $pet['id']; ?>">

          <label>Your Name</label>
          <input type="text" name="adopter_name" required>

          <label>Your Email</label>
          <input type="email" name="adopter_email" required value="<?php echo htmlspecialchars($user_email); ?>">

          <label>Contact Number</label>
          <input type="text" name="contact_no" required>

          <label>Number of Family Members</label>
          <input type="number" name="family_members" min="1">

          <label>Do you have other pets? If yes, please describe</label>
          <textarea name="other_pets"></textarea>

          <label>Full Address</label>
          <textarea name="address" required></textarea>

          <label>Message</label>
          <textarea name="message " required></textarea>

          
          <button class="button" type="submit">Send Application</button>
        </form>
      </div>
  <?php else: ?>
      <p style="color:#555; margin-top:12px;">This pet has already been adopted.</p>
  <?php endif; ?>
</div>

<script src="app.js"></script>
</body>
</html>
