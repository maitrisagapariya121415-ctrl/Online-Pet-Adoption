<?php
include 'db.php';
$admin_pass = 'secret'; // production: change and secure
$logged_in = false;
if (isset($_POST['admin_pass'])) {
    if ($_POST['admin_pass'] === $admin_pass) {
        $logged_in = true;
    } else {
        $err = "Incorrect password.";
    }
} elseif (isset($_POST['logout'])) {
    $logged_in = false;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Admin - Pet Adopt</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <a href="index.php" class="button">Site</a>
  <h1>Admin Panel</h1>

  <?php if (!$logged_in): ?>
    <div class="form">
      <h3>Login</h3>
      <?php if (!empty($err)) echo "<p style='color:red;'>$err</p>"; ?>
      <form method="post">
        <input type="password" name="admin_pass" placeholder="Admin password" required>
        <button class="button" type="submit">Login</button>
      </form>
    </div>
  <?php else: ?>

    <div class="form">
      <h3>Add Pet</h3>
      <form method="post" action="add_pet.php" enctype="multipart/form-data">
        <input name="name" placeholder="Pet name" required>
        <input name="species" placeholder="Species (e.g., Dog, Cat)" required>
        <input name="breed" placeholder="Breed (e.g., Labrador, Persian)">
        <input name="age" placeholder="Age (e.g., 2 years)">

        <!-- Gender Field -->
        <label>Gender:</label>
        <select name="gender" required>
          <option value="">--Select Gender--</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>

        <!-- Weight Field -->
        <label>Weight (kg):</label>
        <input type="number" step="0.01" name="weight" placeholder="e.g., 5.50">

        <!-- Adoption Fee Field -->
        <label>Adoption Fee (Price):</label>
        <input type="number" step="0.01" name="adoption_fee" placeholder="e.g., 1500.00">

        <!-- Behaviour Field -->
        <label>Behaviour:</label>
        <textarea name="behaviour" placeholder="Describe pet's behaviour"></textarea>

        <!-- Image Upload -->
        <label>Image (optional):</label>
        <input type="file" name="image">

        <button class="button" type="submit">Add Pet</button>
      </form>
    </div>

    <div style="margin-top:16px;">
      <h3>Existing Pets</h3>
      <table style="width:100%; background:white; padding:8px;">
        <tr><th>ID</th><th>Name</th><th>Status</th><th>Action</th></tr>
        <?php
        $r = $conn->query("SELECT id,name,status FROM pets ORDER BY id DESC");
        while ($row = $r->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>".htmlspecialchars($row['name'])."</td>
                    <td>{$row['status']}</td>
                    <td>
                      <form style='display:inline' method='post' action='delete_pet.php' onsubmit=\"return confirm('Delete this pet?');\">
                        <input type='hidden' name='id' value='{$row['id']}'>
                        <button class='button red' type='submit'>Delete</button>
                      </form>
                    </td>
                  </tr>";
        }
        ?>
      </table>
    </div>

    <form method="post" style="margin-top:12px;">
      <button type="submit" name="logout" class="button red">Logout</button>
    </form>

  <?php endif; ?>
</div>
<script src="app.js"></script>
</body>
</html>
