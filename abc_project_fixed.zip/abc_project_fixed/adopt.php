<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pet_id         = intval($_POST['pet_id'] ?? 0);
    $name           = trim($_POST['adopter_name'] ?? '');
    $email          = trim($_POST['adopter_email'] ?? '');
    $contact_no     = trim($_POST['contact_no'] ?? '');
    $family_members = !empty($_POST['family_members']) ? intval($_POST['family_members']) : null;
    $other_pets     = trim($_POST['other_pets'] ?? '');
    $address        = trim($_POST['address'] ?? '');
    $message        = trim($_POST['message'] ?? '');

    // Required fields check
    if (!$pet_id || !$name || !$email || !$contact_no || !$address) {
        die("Please fill in all required fields.");
    }

    // Insert adoption application
    $stmt = $conn->prepare("INSERT INTO applications
        (pet_id, adopter_name, adopter_email, contact_no, family_members, other_pets, address, message) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param(
        'isssisss', 
        $pet_id, 
        $name, 
        $email, 
        $contact_no, 
        $family_members, 
        $other_pets, 
        $address, 
        $message
    );

    if ($stmt->execute()) {
        // Update pet status
        $u = $conn->prepare("UPDATE pets SET status='adopted' WHERE id=?");
        if ($u) {
            $u->bind_param('i', $pet_id);
            $u->execute();
            $u->close();
        }

        echo "<p style='padding:16px;background:#e9ffe9;border:1px solid #c7f0c7;'>
                Your application has been successfully submitted. Thank you!
              </p>";
        echo "<p><a href='index.php' class='button'>Go back to Home</a></p>";
    } else {
        echo "Error inserting application: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!-- Adoption Application Form -->
<form action="" method="post">
    <input type="hidden" name="pet_id" value="<?php echo htmlspecialchars($_GET['pet_id'] ?? ''); ?>">

    <label>Name:</label>
    <input type="text" name="adopter_name" required>

    <label>Email:</label>
    <input type="email" name="adopter_email" required>

    <label>Contact Number:</label>
    <input type="text" name="contact_no" required>

    <label>Number of Family Members:</label>
    <input type="number" name="family_members">

    <label>Other Pets:</label>
    <textarea name="other_pets"></textarea>

    <label>Address:</label>
    <textarea name="address" required></textarea>

    <label>Message:</label>
    <textarea name="message"></textarea>

    <button type="submit">Apply</button>
</form>
